/******************** (C) COPYRIGHT 2020 STMicroelectronics **************************************
* File Name          : readme.txt
* Author             : STMicroelectronics
* Version            : V1.0
* Date               : 02/06/2020
* Description        : This file describes how to add STM32G4 devices support on EWARM 
**************************************************************************************************

Running the "EWARMv8_STM32G49_G4xxP_Support_V1.0.exe" adds the following:
  
1. Part numbers for  :
- Product lines: STM32G491xx/STM32G4A1xx
- Adding new package BGA121 support: STM32G4xxP
- Adding devices: STM32G474QE and STM32G484QE

2. Automatic flash algorithm selection

3. SVD files


How to use:
==========
* Before installing the files mentioned above, you need to have EWARM v8.xx 
or later installed. 
You can download EWARM from IAR web site @ www.iar.com
 
* Run "EWARMv8_STM32G49_G4xxP_Support_V1.0.exe"  at EWARM install directory.
EWARM Install Directory is set by default to "C:\Program Files\IAR Systems\Embedded Workbench \", 
please change it manually if you have EWARM installed at different location.

******************* (C) COPYRIGHT 2020 STMicroelectronics *****END OF FILE************************





	



