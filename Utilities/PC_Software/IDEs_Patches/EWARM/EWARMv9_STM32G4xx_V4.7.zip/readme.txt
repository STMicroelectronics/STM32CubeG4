**
  ************************************************************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32G4xx devices support on EWARM.
  ************************************************************************************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  **************************************************************************************************************************************************
  These packages contains the needed files to be installed in order to support STM32G4xx 
  devices by EWARM9 and laters.

  Package purpose:
  ==================================================================================================================================================
  We inform you that this package is suitable for internal & external use.
  EWARMv9_STM32G4xx_V4.7.exe has been digitally signed by STMicroelectronics.


  By running the "Install_Patch.bat" file (as an administrator), the following actions will be performed: 
  ==================================================================================================================================================
	1. If you have previously installed an STM32 patch, it will be removed during the first run. 
	2. The following items will be added :
         - Product lines: STM32G411x6/STM32G411x8/STM32G411xB/STM32G414xB/STM32G414xC/STM32G411xC/STM32G431x6/G431x8/G431xB/G441x6/G441x8/G441xB/G471xC/G471xE/G471xB/G473xB/G473xC/G473xE/G474xB/G474xC/G474xE/G483xE/G484xE/G4A1xE/G491xC/G491xE
	     - New line to E-bike market: STM32GBK1xx
	     - New package BGA121 support: STM32G4xxP
         - STM32G474E_EVAL dedicated connection with QSPI external loader support
	
	- Automatic STM32G4 flash algorithm selection
    
	3. The following SVD files will be added:
	- STM32G4xx SVD files  V2.5.
  

  PS: When using external loader on EWARM, please unselect the verify from the debug menu.The verification is done by the flashloader.
      That you can run EWARMv9_STM32G4xx_V4.7.exe only if the uninstall is not needed.

 How to use:
 ==================================================================================================================================================
 * Before installing the files mentioned above, you need to have EWARM v9.xx.x or later installed. 
 
  You can download EWARM from IAR web site @ www.iar.com
 
 * Run "EWARMv9_STM32G4xx_V4.7.exe" or using the "Install_Patch.bat" as administrator on EWARM install directory.
   Ewarm Install Directory is "C:\Program Files\IAR Systems\Embedded Workbench \".
   Please change it manually if you have EWARM installed at a different location.   

 PS: Please make sure to use the highest frequency while using the macro-flashloader to have a better performance.

 SVD files ReleaseNotes:
 ==================================================================================================================================================
    V1.0   First release: adding support to STM32G431xx/G471xx/G441xx/G473xx/G474xx/G484xx/G483xx devices
    V1.1   Renamed SHCRS into SHCSR in SCB, Updated MPU/IWDG/WWDG, Corrected FPU_CPACR base address
    V1.2   The COMP_C4CSR address offset has been fixed, NVIC peripheral has been updated
    V1.3   Corrected ADC12 address and registers
    V1.4   Fixing base address for SCB, Renaming SCB_ACTRL into SCB_ACTLR
    V1.5   Adding support to STM32G491xx/G4A1xx
    V1.6   Fixing ADC_CFGR fields, Adding missing TIM16/17_OR1 register
    V1.7   Fixing FDCAN registers in all G4 series
    V1.8   Fixing COMP registers in all G4 series and updating License section
    V1.9   Fixing FDCAN interrupts in all G4 series according to latest update in RM0440
    V2.0   Updating PWR and RCC in all G4 series according to RM0440-Rev6
    V2.1   Updating FDCAN,RCC & Clean up in all G4 series according to RM0440-Rev7
    V2.2   Update in FDCAN according to RM0440-Rev7
    V2.3   Update in interrupts for G4 family
	V2.4   Update in FLASH register for G4 family
    V2.5   Update in EXTI register for G4 family