/**
  ************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32G4xx devices support on EWARM.
  ************************************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                      www.st.com/SLA0044
  *
  *************************************************************************************************
These packages contains the needed files to be installed in order to support STM32G4xx 
  devices by EWARM8 and laters.

1. If you have already installed an STM32G4 patch before, you can remove it by running 
  Uninstall_Patch.bat (run as administrator).

  2. Running the "EWARMv8_STM32G4xx_V4.1.exe" adds the following:
    - Product lines: STM32G431x6/G431x8/G431xB/G441x6/G441x8/G441xB/G471xC/G471xE/G471xB/G473xB/G473xC/G473xE/G474xB/G474xC/G474xE/G483xE/G484xE
	- New line to E-bike market: STM32GBK1xx
	- New package BGA121 support: STM32G4xxP
    - STM32G474E_EVAL dedicated connection with QSPI external loader support
	
3. Automatic STM32G4 flash algorithm selection

4. SVD files

PS: when using external loader on EWARM, please unselect the verify from the debug menu
  
How to use:
==========
* Before installing the files mentioned above, you need to have EWARM v8.xx 
or later installed. 
You can download EWARM from IAR web site @ www.iar.com
 
* Run "EWARMv8_STM32G4xx_V4.1.exe"  at EWARM install directory.
EWARM Install Directory is set by default to "C:\Program Files\IAR Systems\Embedded Workbench \", 
please change it manually if you have EWARM installed at different location.

******************* (C) COPYRIGHT 2020 STMicroelectronics *****END OF FILE************************





	



