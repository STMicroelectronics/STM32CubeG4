/**
  ************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32G4 devices support on MDK-ARM.
  ************************************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                      www.st.com/SLA0044
  *
  *************************************************************************************************
  

Running the "Keil.STM32G4xx_DFP.1.2.1.pack" adds the following:
  
1. Part numbers for  :
 - Product lines: STM32G431x6xx/STM32G431x8xx/STM32G431xBxx/STM32G441xBxx/STM32G471xCxx/STM32G471xExx/STM32G473xBxx/STM32G473xCxx/STM32G473xExx/STM32G474xBxx/STM32G474xCxx/STM32G474xExx/
				  STM32G483xExx/STM32G484xExx/STM32G491xCxx/STM32G491xExx/STM32G4A1xCxx/STM32G4A1xExx/STM32GBK1CB         
 - deleted CPN: STM32G474VEIx
  
2. Automatic STM32G4  flash algorithm selection 
    
3. SVD file.


How to use:
==========
* Before installing the files mentioned above, you need to have MDK-ARM v5.25 or later installed. 
You can download pack from keil web site @ www.keil.com
 
* Double Clic on  "Keil.STM32G4xx_DFP.1.2.1.pack" in order to install this pack in 
the Keil install directory.

******************* (C) COPYRIGHT 2021 STMicroelectronics *****END OF FILE************************





	



