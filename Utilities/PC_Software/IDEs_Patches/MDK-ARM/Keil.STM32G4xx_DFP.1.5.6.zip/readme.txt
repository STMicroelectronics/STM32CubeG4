/**
  ************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32G4xx devices support on MDK-ARM.
  ************************************************************************************************
   * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ************************************************************************************************/
  
  Package general purpose:
 ===============================================================================================================================
	These packages contains the needed files to be installed in order to support STM32G4xx devices by MDK-ARM v5.25 and laters.
 
	We inform you that this package is suitable for internal & external use.
	
  Running the "Keil.STM32G4xx_DFP.1.5.6.pack" adds the following:   
  ==================================================================================================================================================

    1. If you have previously installed an STM32 patch, it will be removed during the first run. 
	2. The following items will be added :
        - Product lines: STM32G411x6/STM32G411x8/STM32G411xB/STM32G414xB/STM32G414xC/STM32G411xC/STM32G431x6/G431x8/G431xB/G441x6/G441x8/G441xB/G471xC/G471xE/G471xB/G473xB/G473xC/G473xE/G474xB/G474xC/G474xE/G483xE/G484xE/G4A1xE/G491xC/G491xE
		- New line to E-bike market: STM32GBK1xx
		- New package BGA121 support: STM32G4xxP
		- STM32G474E_EVAL dedicated connection with QSPI external loader support
	
	- Automatic STM32G4 flash algorithm selection
    
	3. The following SVD files will be added:
	- STM32G4xx SVD files  V2.5.

  
  How to use:
  ===============================================================================================================================
	* Before installing the files mentioned above, you need to have MDK-ARM v5.25 
	  or later installed. 
	  You can download pack from keil web site @ www.keil.com
	 
	* Double Clic on  "Keil.STM32G4xx_DFP.1.5.6.pack" in order to install this pack in 
	  the Keil install directory.
	  
    PS: Please make sure that you are using PackUnzip.exe to run this pack.
  
 SVD files ReleaseNotes:
 ==================================================================================================================================================

    V1.0   First release: adding support to STM32G431xx/G471xx/G441xx/G473xx/G474xx/G484xx/G483xx devices
    V1.1   Renamed SHCRS into SHCSR in SCB, Updated MPU/IWDG/WWDG, Corrected FPU_CPACR base address
    V1.2   The COMP_C4CSR address offset has been fixed, NVIC peripheral has been updated
    V1.3   Corrected ADC12 address and registers
    V1.4   Fixing base address for SCB, Renaming SCB_ACTRL into SCB_ACTLR
    V1.5   Adding support to STM32G491xx/G4A1xx
    V1.6   Fixing ADC_CFGR fields, Adding missing TIM16/17_OR1 register
    V1.7   Fixing FDCAN registers in all G4 series
    V1.8   Fixing COMP registers in all G4 series and updating License section
    V1.9   Fixing FDCAN interrupts in all G4 series according to latest update in RM0440
    V2.0   Updating PWR and RCC in all G4 series according to RM0440-Rev6
    V2.1   Updating FDCAN,RCC & Clean up in all G4 series according to RM0440-Rev7
    V2.2   Update in FDCAN according to RM0440-Rev7
    V2.3   Update in interrupts for G4 family
	V2.4   Update in FLASH register for G4 family
    V2.5   Update in EXTI register for G4 family






	



