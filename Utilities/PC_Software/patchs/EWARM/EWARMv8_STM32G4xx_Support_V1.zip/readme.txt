/******************** (C) COPYRIGHT 2019 STMicroelectronics **************************************
* File Name          : readme.txt
* Author             : STMicroelectronics
* Description        : This file describes how to add STM32G4xx devices support on EWARM 
**************************************************************************************************

Running the "EWARMv8_STM32G4xx_Support_V1.exe" adds the following:
  
1. Part numbers for  :
- Product lines: STM32G431xx/G471xx/G441xx/G473xx/G474xx
- New line to E-bike market: STM32GBK1xx

2. Automatic STM32G4 flash algorithm selection

3. SVD file 


How to use:
==========
* Before installing the files mentioned above, you need to have EWARM v8.xx 
or later installed. 
You can download EWARM from IAR web site @ www.iar.com
 
* Run "EWARMv8_STM32G4xx_Support_V1.exe"  at EWARM install directory.
EWARM Install Directory is set by default to "C:\Program Files\IAR Systems\Embedded Workbench \", 
please change it manually if you have EWARM installed at different location.

******************* (C) COPYRIGHT 2019 STMicroelectronics *****END OF FILE************************





	



