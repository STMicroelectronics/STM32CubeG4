/******************** (C) COPYRIGHT 2019 STMicroelectronics **************************************
* File Name          : readme.txt
* Author             : STMicroelectronics
* Description        : This file describes how to add STM32G4xx devices support on MDK-ARM 
**************************************************************************************************

Running the "Keil.STM32G4xx_DFP.1.0.0.pack" adds the following:
  
1. Part numbers for  :
- Product lines: STM32G431xx/G471xx/G441xx/G473xx/G474xx
- New line to E-bike market: STM32GBK1xx

2. Automatic STM32G4 flash algorithm selection

3. SVD file 


How to use:
==========
* Before installing the files mentioned above, you need to have MDK-ARM v5.25 
or later installed. 
You can download pack from keil web site @ www.keil.com
 
* Double Clic on  "Keil.STM32G4xx_DFP.1.0.0.pack" in order to install this pack in 
the Keil install directory.

******************* (C) COPYRIGHT 2019 STMicroelectronics *****END OF FILE************************





	



